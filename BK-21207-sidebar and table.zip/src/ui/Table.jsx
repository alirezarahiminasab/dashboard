import { FaSortUp } from "react-icons/fa6";
import { FaSort } from "react-icons/fa";

import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";

export default function Table() {
  return (
    <div role="table" className="table">
      <Filters />
      <Headers />
      <Content />

      {/* <Rows /> */}
    </div>
  );
}

function Filters() {
  return (
    <div className="table__filters">
      <div className="btns">
        <button className="btn active">Lab Reports</button>
        <button className="btn">Prescription</button>
        <button className="btn">Medication </button>
        <button className="btn">Dignosis</button>
        <button className="btn">5+</button>
      </div>
      <select value="Recent" className="dropdown">
        <option value="recent">Recent</option>
        <option value="last-7">Last 7 Days</option>
      </select>
    </div>
  );
}

const headers = [
  { name: "Test Name", icon: <FaSortUp /> },
  { name: "Referred by", icon: <FaSort /> },
  { name: "Date", icon: <FaSort /> },
  { name: "Comments" },
  { name: "Result" },
];

function Headers() {
  return (
    <div className="table__row">
      {headers.map((h) =>
        h.icon ? (
          <button key={h.name}>
            {h.name}
            {h.icon}
          </button>
        ) : (
          <div key={h.name}>{h.name}</div>
        )
      )}
    </div>
  );
}

const ContentData = [
  [
    "Electrocardiography",
    "Dr. Raficul islam",
    "28 Jan, 2024",
    "Good! Take rest",
    "Normal",
  ],
  [
    "Liver biopsy",
    "Dr. Fahim Ahmed",
    "12 Jan, 2024",
    "Waiting for diagram",
    "Hepatitis",
  ],
];

function Content() {
  return ContentData.map((row, i) => (
    <div key={row[0] + i} className="table__row">
      {row.map((col, j) => (
        <div key={j + col} className={j === 4 ? "label" : ""}>
          {col}
        </div>
      ))}
    </div>
  ));
}
