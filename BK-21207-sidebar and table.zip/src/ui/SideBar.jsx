import { useState } from "react";
import { NavLink } from "react-router-dom";

import { BiLogOut } from "react-icons/bi";
import { TbSettings } from "react-icons/tb";
import { BiSolidDashboard } from "react-icons/bi";
import {
  IoBag,
  IoBagOutline,
  IoPeopleOutline,
  IoPeopleSharp,
  IoPersonOutline,
  IoPersonSharp,
} from "react-icons/io5";
import { IoIosHelpCircleOutline, IoIosHelpCircle } from "react-icons/io";
import { LuLayoutDashboard } from "react-icons/lu";
import {
  HiOutlineClipboardDocumentList,
  HiMiniClipboardDocumentList,
} from "react-icons/hi2";
import { MdOutlineNotificationsActive } from "react-icons/md";
const navListData = [
  {
    name: "Dashboard",
    icon1: <LuLayoutDashboard />,
    icon2: <BiSolidDashboard />,
    path: "/dashboard",
  },
  {
    name: "Appointments",
    icon1: <IoBagOutline />,
    icon2: <IoBag />,
    path: "",
  },
  {
    name: "Analytics",
    icon1: <IoPeopleOutline />,
    icon2: <IoPeopleSharp />,
    path: "",
  },
  {
    name: "Doctor",
    icon1: <IoPersonOutline />,
    icon2: <IoPersonSharp />,
    path: "",
  },
  {
    name: "Reports",
    icon1: <HiOutlineClipboardDocumentList />,
    icon2: <HiMiniClipboardDocumentList />,
    path: "",
  },
  {
    name: "Help",
    icon1: <IoIosHelpCircleOutline />,
    icon2: <IoIosHelpCircle />,
    path: "",
  },
];

export default function SideBar() {
  return (
    <aside className="sidebar">
      <NavList />
      <AccountCard />
    </aside>
  );
}

function NavList() {
  const [hover, setHover] = useState("Dashboard");
  return (
    <nav>
      <ul className="nav-list">
        {navListData.map(({ name, icon1, icon2, path = "" }) => (
          <li
            key={name}
            onMouseEnter={() => setHover(name)}
            onMouseLeave={() => setHover("")}
          >
            <NavLink to={path} className="nav-item">
              {name === "Dashboard" && icon2}
              {name !== "Dashboard" && name === hover && icon2}
              {name !== "Dashboard" && name !== hover && icon1}
              <span>{name}</span>
            </NavLink>
          </li>
        ))}
      </ul>
    </nav>
  );
}

function AccountCard() {
  return (
    <div className="account-card">
      <img src="avatar4.png" className="avatar" />
      <h1>Dr. Rahimi Nasab</h1>
      <h2>Super Admin</h2>
      <div className="btns">
        <button className="btn">
          <TbSettings />
        </button>
        <button className="btn">
          <BiLogOut />
        </button>
      </div>
    </div>
  );
}
