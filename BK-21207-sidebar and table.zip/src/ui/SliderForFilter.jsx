function Slider() {
  return (
    <Swiper slidesPerView={"auto"} spaceBetween={5} className="mySwiper">
      <SwiperSlide className="slide active">Slideeeeeeeee 1</SwiperSlide>
      <SwiperSlide className="slide">Slide 2</SwiperSlide>
      <SwiperSlide className="slide">Slide 3</SwiperSlide>
      <SwiperSlide className="slide">Slideeee 4</SwiperSlide>
      <SwiperSlide className="slide">Sliiiiiide 5</SwiperSlide>
      <SwiperSlide className="slide">Slide 6</SwiperSlide>
      <SwiperSlide className="slide">Slllllide 7</SwiperSlide>
      <SwiperSlide className="slide">Slide 8</SwiperSlide>
      <SwiperSlide className="slide">SSSSSSSSSSlide 9</SwiperSlide>
    </Swiper>
  );
}
