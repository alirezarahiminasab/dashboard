export default function Logo() {
  return (
    <div className="logo-container">
      <img className="logo" src="logo.png" alt="Logo" />
      <span>Nexus</span>
    </div>
  );
}
