import Table from "../ui/Table";

export default function Dashboard() {
  return (
    <div className="dashboard">
      <Table />
    </div>
  );
}
